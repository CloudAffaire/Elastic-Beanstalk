<!DOCTYPE html>
<html lang="en">
    <head>
        <title>MyShoppingListV2.0</title>
        <link href="bootstrap-cosmo.css" rel="stylesheet">
        <link href="style.css" rel="stylesheet">
    </head>
    <body>
<div class="row">
    <div id="message_cont"></div>
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">MyShoppingListV2.0</h3>
        </div>
        <div class="panel-body">

            <div class="col-lg-12" style="padding-left: 0; padding-right: 0;" >
                
                <div class="pull-left" >
                    <button class="btn btn-danger"><span class="glyphicon glyphicon-remove-circle"></span> Clear List</button>              
                </div>
                <div class="pull-right" ><a href="#" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span> Add New Item</a></div>  
            </div>
            <div style="margin-bottom: 10px;" class="clearfix"></div>               
                    <table class="table table-striped table-hover table-bordered ">
                        <thead>
                            <tr>
                                <th style="text-align: left;width: 80%;">Items</th>
                            </tr>
                        </thead>
                        <tbody>
                                <tr>
                                    <td style="text-align: left;vertical-align: middle;">Pizza</td>
                                 </tr>
                                 <tr>
                                    <td style="text-align: left;vertical-align: middle;">Pasta</td>
                                 </tr>
                                 <tr>
                                    <td style="text-align: left;vertical-align: middle;">Sauce</td>
                                 </tr>
                                 <tr>
                                    <td style="text-align: left;vertical-align: middle;">Mayonnaise</td>
                                 </tr>                       
                        </tbody>
                    </table>
        </div>
    </div>
</div>
</body>
</html>