<?php
require_once 'config.php';
include 'header.php';

try {
    $sql = "SELECT `itl_id`,`itl_items`,`itl_status` FROM tbl_items_list WHERE 1 ORDER BY itl_id ASC ";
    $stmt = $DB->prepare($sql);
    $stmt->execute();
    $results = $stmt->fetchAll();
} catch (Exception $ex) {
    echo $ex->getMessage();
}
?>
<div class="row">
    <div id="message_cont"></div>
    <div class="panel panel-primary">
        <div class="panel-heading">
            <h3 class="panel-title">MyShoppingList</h3>
        </div>
        <div class="panel-body">

            <div class="col-lg-12" style="padding-left: 0; padding-right: 0;" >
                
                <div class="pull-left" >
                    
                    <?php if (count($results) > 0) { ?>
                    <a class="btn btn-danger" href="process_form.php?mode=clear" onclick="return confirm('Are you sure you want to clear the list?')"><span class="glyphicon glyphicon-remove-circle"></span> Clear List</a>
                    <?php } else { ?>
                    <button class="btn btn-danger" disabled="" ><span class="glyphicon glyphicon-remove-circle"></span> Clear List</button>
                    <?php } ?>                   
                </div>

                <div class="pull-right" ><a href="add-item.php" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span> Add New Item</a></div>

                
            </div>

            <div style="margin-bottom: 10px;" class="clearfix"></div>
            <?php if (count($results) > 0) { ?>
                <div style="margin: 5px;display: none;" class="clearfix" id="loader">
                    Loading...
                </div>
                
                    <table class="table table-striped table-hover table-bordered ">
                        <thead>
                            <tr>
                                <th style="width: 10%;"></th>
                                <th style="text-align: left;width: 80%;">Items</th>
                                <th style="width: 10%;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($results as $res) {
                                $item_status = intval($res["itl_status"]);
                                ?>
                                <tr>
                                    <td style="text-align: center;vertical-align: middle;">
                                        <input type="checkbox" name="item[]" value="<?php echo intval($res["itl_id"]); ?>" <?php echo ($item_status == 1) ? 'checked' : ''; ?> class="chk" >
                                    </td>
                                    <td style="text-align: left;vertical-align: middle;"><?php echo trim($res["itl_items"]); ?></td>
                                    <td style="vertical-align: middle;text-align: center;">
                                        <a style="color: #f00;" href="process_form.php?mode=delete&id=<?php echo intval($res["itl_id"]); ?>" onclick="return confirm('Are you sure you want to delete [<?php echo addslashes(trim($res["itl_items"])); ?>] ?')"><span class="glyphicon glyphicon-remove-circle" style="font-size:18px;"></span> </a> </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                
            <?php } else { ?>
                <div class="well well-lg">No items in the list.</div>
            <?php } ?>
        </div>
    </div>
</div>
<?php
include 'footer.php';
?>