<?php
error_reporting( E_ALL & ~E_DEPRECATED & ~E_NOTICE );
ob_start();
session_start();

$SITE_URL = 'http://myshoppinglist.ap-south-1.elasticbeanstalk.com/';

$dbhost = $_SERVER['RDS_HOSTNAME'];
$dbport = $_SERVER['RDS_PORT'];
$dbname = $_SERVER['RDS_DB_NAME'];
$charset = 'utf8' ;

$dsn = "mysql:host={$dbhost};port={$dbport};dbname={$dbname};charset={$charset}";
$username = $_SERVER['RDS_USERNAME'];
$password = $_SERVER['RDS_PASSWORD'];

$pdo = new PDO($dsn, $username, $password);


try {
  $DB = new PDO($dsn, $username, $password); 
  $sql_create_table_tbl_items_list = <<<EOSQL
CREATE TABLE IF NOT EXISTS `tbl_items_list` (
  `itl_id` int(11) NOT NULL AUTO_INCREMENT,
  `itl_items` varchar(255) NOT NULL,
  `itl_status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`itl_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1
EOSQL;
$msg = '';
$RESULT = $DB->exec($sql_create_table_tbl_items_list);
} catch (Exception $ex) {
  echo $ex->getMessage();
  die;
}

//get error/success messages
if ($_SESSION["errorType"] != "" && $_SESSION["errorMsg"] != "" ) {
    $ERROR_TYPE = $_SESSION["errorType"];
    $ERROR_MSG = $_SESSION["errorMsg"];
    $_SESSION["errorType"] = "";
    $_SESSION["errorMsg"] = "";
}
?>